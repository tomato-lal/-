from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
import os

# 创建数据库实例
db = SQLAlchemy()
# 创建登录管理器实例
login_manager = LoginManager()

# 应用工厂函数
def create_app():
    # 创建Flask应用实例
    app = Flask(__name__, template_folder='../templates', static_folder='../static')
    
    # 确保正确的字符编码处理
    app.config['JSON_AS_ASCII'] = False
    app.config['JSONIFY_MIMETYPE'] = 'application/json; charset=utf-8'
    
    # 配置应用
    app.config.from_object('config.config.Config')
    
    # 初始化数据库
    db.init_app(app)
    
    # 初始化登录管理器
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'  # 设置登录视图
    login_manager.login_message = '请先登录'
    
    # 注册蓝图
    from app.auth import auth_bp
    from app.main import main_bp
    
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(main_bp)
    
    return app
