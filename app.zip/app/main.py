import json
import os
import sys
import re
import uuid
# 添加codedemo目录到Python路径
# 当前文件路径: app/main.py
# 目标目录: GovInfoToFileSystem/codedemo
# 正确路径计算：
# 1. 获取当前文件的目录：os.path.dirname(__file__) -> app
# 2. 向上走1级到smart_lookout：os.path.dirname(...) -> smart_lookout
# 3. 向上走1级到GovInfoToFileSystem：os.path.dirname(...) -> GovInfoToFileSystem
# 4. 进入codedemo目录：os.path.join(..., 'codedemo')
gov_info_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
codedemo_path = os.path.join(gov_info_path, 'codedemo')
sys.path.append(codedemo_path)
print(f"当前文件路径: {os.path.abspath(__file__)}")
print(f"gov_info_path: {gov_info_path}")
print(f"codedemo_path: {codedemo_path}")
print(f"文件是否存在: {os.path.exists(os.path.join(codedemo_path, 'baidu_spider.py'))}")
print(f"gov_info_path内容: {os.listdir(gov_info_path) if os.path.exists(gov_info_path) else '目录不存在'}")
from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, send_from_directory
from flask_login import login_required, current_user
from datetime import datetime
from app import db
from app.models import CrawledData, Report
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.lib import colors
from io import BytesIO
import base64
from PIL import Image as PILImage
# 直接导入爬虫函数
from baidu_spider import baidu_spider, bing_search_baidu
import sys
import os
# 导入数据分析模块
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(project_root)
from data_analysis import DataAnalysisTool

# 创建主蓝图
main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """首页重定向到登录页面"""
    return redirect(url_for('auth.login'))

@main_bp.route('/data_analysis', methods=['GET', 'POST'])
@login_required
def data_analysis():
    """数据分析页面"""
    analysis_tool = DataAnalysisTool()
    results = None
    error = None
    
    if request.method == 'POST':
        try:
            # 运行数据分析
            raw_data = analysis_tool.get_all_data()
            
            if not raw_data:
                error = "没有数据可以分析，请先进行数据爬取"
            else:
                df = analysis_tool.convert_to_dataframe(raw_data)
                original_count = len(df)
                cleaned_df = analysis_tool.clean_data(df)
                cleaned_count = len(cleaned_df)
                # 保存清洗前后的数据量信息
                results = analysis_tool.analyze_data(cleaned_df)
                results['original_count'] = original_count
                results['cleaned_count'] = cleaned_count
                
                # 导出数据（可选）
                if request.form.get('export'):
                    analysis_tool.export_clean_data(cleaned_df, f'cleaned_data_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv')
                    flash('数据已成功导出', 'success')
        except Exception as e:
            error = f"数据分析失败：{str(e)}"
    
    return render_template('data_analysis.html', results=results, error=error)

@main_bp.route('/dashboard')
@login_required
def dashboard():
    """后台仪表盘"""
    return render_template('dashboard.html')

@main_bp.route('/search', methods=['GET', 'POST'])
@login_required
def search():
    """搜索功能"""
    if request.method == 'POST':
        try:
            keyword = request.form.get('keyword', '').strip()
            num = int(request.form.get('num', 5))
            
            if not keyword:
                flash('请输入搜索关键词！', 'error')
                return redirect(url_for('main.search'))
            
            # 直接调用爬虫函数，不使用subprocess
            crawled_results = []
            
            # 调用百度爬虫
            baidu_results = baidu_spider(keyword, num)
            for result in baidu_results:
                crawled_results.append({
                    'source': 'baidu',
                    'keyword': keyword,
                    'title': result['title'],
                    'content': result['summary'],
                    'url': result['url'],
                    'cover_url': result['cover_url']
                })
            
            # 调用必应爬虫
            bing_results = bing_search_baidu(keyword, num)
            for result in bing_results:
                crawled_results.append({
                    'source': 'bing',
                    'keyword': keyword,
                    'title': result['title'],
                    'content': result['summary'],
                    'url': result['url'],
                    'cover_url': result['cover_url']
                })
            
            if not crawled_results:
                flash('未获取到搜索结果！', 'warning')
                return redirect(url_for('main.search'))
            
            return render_template('search_results.html', results=crawled_results, keyword=keyword)
            
        except Exception as e:
            flash(f'搜索过程中出错：{str(e)}', 'error')
            return redirect(url_for('main.search'))
    
    return render_template('search.html')

@main_bp.route('/save_selected', methods=['POST'])
@login_required
def save_selected():
    """保存选中的搜索结果"""
    try:
        data = request.get_json()
        selected_ids = data.get('selected_ids', [])
        results = data.get('results', [])
        
        if not selected_ids:
            return jsonify({'status': 'error', 'message': '请选择要保存的数据！'})
        
        saved_count = 0
        for idx in selected_ids:
            if 0 <= idx < len(results):
                result = results[idx]
                # 检查是否已存在相同URL的数据
                existing_data = CrawledData.query.filter_by(url=result['url']).first()
                if not existing_data:
                    # 确保所有字符串都使用正确的UTF-8编码
                    def ensure_utf8(s):
                        if isinstance(s, str):
                            return s
                        elif isinstance(s, bytes):
                            return s.decode('utf-8', errors='replace')
                        return str(s)
                    
                    new_data = CrawledData(
                        keyword=ensure_utf8(result['keyword']),
                        source=ensure_utf8(result['source']),
                        title=ensure_utf8(result['title']),
                        content=ensure_utf8(result.get('content', '')),
                        url=ensure_utf8(result['url']),
                        cover_url=ensure_utf8(result.get('cover_url', '')),
                        saved_by=current_user.id
                    )
                    db.session.add(new_data)
                    saved_count += 1
        
        db.session.commit()
        return jsonify({'status': 'success', 'message': f'成功保存 {saved_count} 条数据！'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': 'error', 'message': f'保存失败：{str(e)}'})

def generate_pdf(report):
    """生成PDF报告"""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    import os
    
    # 确保PDF保存目录存在
    pdf_dir = os.path.join(os.path.dirname(__file__), 'static', 'pdfs')
    os.makedirs(pdf_dir, exist_ok=True)
    
    # 创建PDF文档
    pdf_filename = f"report_{uuid.uuid4().hex[:8]}.pdf"
    pdf_path = os.path.join(pdf_dir, pdf_filename)
    
    try:
        # 注册中文字体
        font_registered = False
        # 尝试使用系统自带的中文字体
        font_paths = [
            'C:/Windows/Fonts/simhei.ttf',  # 黑体
            'C:/Windows/Fonts/simsun.ttc',  # 宋体
            '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',  # Linux下的文泉驿微米黑
        ]
        
        for font_path in font_paths:
            if os.path.exists(font_path):
                if font_path.endswith('.ttc'):
                    # 对于TrueType集合文件，需要指定索引
                    pdfmetrics.registerFont(TTFont('SimSun', font_path, subfontIndex=0))
                    # 同时尝试注册黑体（如果在集合中）
                    try:
                        pdfmetrics.registerFont(TTFont('SimHei', font_path, subfontIndex=1))
                    except:
                        pass
                else:
                    pdfmetrics.registerFont(TTFont('SimHei', font_path))
                font_registered = True
                break
        
        # 创建PDF文档对象
        doc = SimpleDocTemplate(pdf_path, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
        
        # 样式表
        styles = getSampleStyleSheet()
        
        # 选择中文字体
        chinese_font = 'SimHei' if 'SimHei' in pdfmetrics.getRegisteredFontNames() else 'SimSun' if 'SimSun' in pdfmetrics.getRegisteredFontNames() else 'Helvetica'
        
        # 自定义样式 - 使用支持中文的字体
        title_style = ParagraphStyle(
            'TitleStyle',
            parent=styles['Heading1'],
            fontName=chinese_font,
            fontSize=20,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#003366')
        )
        
        heading_style = ParagraphStyle(
            'HeadingStyle',
            parent=styles['Heading2'],
            fontName=chinese_font,
            fontSize=16,
            alignment=TA_LEFT,
            textColor=colors.HexColor('#003366')
        )
        
        content_style = ParagraphStyle(
            'ContentStyle',
            parent=styles['BodyText'],
            fontName=chinese_font,
            fontSize=12,
            alignment=TA_JUSTIFY,
            leading=18
        )
        
        data_style = ParagraphStyle(
            'DataStyle',
            parent=styles['BodyText'],
            fontName=chinese_font,
            fontSize=10,
            alignment=TA_LEFT,
            leading=16
        )
        
        # 构建PDF内容
        content = []
        
        # 添加标题
        content.append(Paragraph(report.title, title_style))
        content.append(Spacer(1, 20))
        
        # 添加报告生成日期
        content.append(Paragraph(f"报告生成日期：{report.created_at.strftime('%Y年%m月%d日 %H:%M:%S')}", content_style))
        content.append(Paragraph(f"生成人：{report.user.username}", content_style))
        content.append(Spacer(1, 20))
        
        # 添加报告内容
        if report.content:
            content.append(Paragraph("一、分析报告", heading_style))
            content.append(Spacer(1, 10))
            
            # 处理换行符
            paragraphs = report.content.split('\n')
            for para in paragraphs:
                if para.strip():
                    content.append(Paragraph(para.strip(), content_style))
                    content.append(Spacer(1, 10))
        
        # 添加数据来源
        if report.crawled_data:
            content.append(Paragraph("二、数据来源", heading_style))
            content.append(Spacer(1, 10))
            
            for i, data in enumerate(report.crawled_data, 1):
                content.append(Paragraph(f"{i}. {data.title}", data_style))
                content.append(Paragraph(f"   来源：{'百度' if data.source == 'baidu' else '必应'}", data_style))
                content.append(Paragraph(f"   日期：{data.crawled_at.strftime('%Y-%m-%d %H:%M')}", data_style))
                content.append(Paragraph(f"   URL：{data.url}", data_style))
                
                if data.content:
                    # 截取部分内容
                    content_preview = data.content[:200] + "..." if len(data.content) > 200 else data.content
                    content.append(Paragraph(f"   内容摘要：{content_preview}", data_style))
                
                content.append(Spacer(1, 15))
        
        # 生成PDF
        doc.build(content)
    except Exception as e:
        # 如果发生错误，使用更简单的方式生成PDF
        from reportlab.pdfgen import canvas
        
        c = canvas.Canvas(pdf_path, pagesize=A4)
        width, height = A4
        
        # 设置字体
        try:
            c.setFont("SimHei", 12) if "SimHei" in pdfmetrics.getRegisteredFontNames() else c.setFont("Helvetica", 12)
        except:
            c.setFont("Helvetica", 12)
        
        # 绘制标题
        c.drawString(100, height - 100, report.title)
        c.drawString(100, height - 120, f"报告生成日期：{report.created_at.strftime('%Y年%m月%d日 %H:%M:%S')}")
        c.drawString(100, height - 140, f"生成人：{report.user.username}")
        
        # 绘制报告内容
        y = height - 180
        if report.content:
            c.drawString(100, y, "一、分析报告")
            y -= 20
            paragraphs = report.content.split('\n')
            for para in paragraphs:
                if para.strip():
                    if y < 100:
                        c.showPage()
                        y = height - 50
                        try:
                            c.setFont("SimHei", 12) if "SimHei" in pdfmetrics.getRegisteredFontNames() else c.setFont("Helvetica", 12)
                        except:
                            c.setFont("Helvetica", 12)
                    c.drawString(100, y, para.strip()[:200])
                    y -= 20
        
        # 绘制数据来源
        if report.crawled_data:
            if y < 150:
                c.showPage()
                y = height - 100
                try:
                    c.setFont("SimHei", 12) if "SimHei" in pdfmetrics.getRegisteredFontNames() else c.setFont("Helvetica", 12)
                except:
                    c.setFont("Helvetica", 12)
            c.drawString(100, y, "二、数据来源")
            y -= 20
            
            for i, data in enumerate(report.crawled_data, 1):
                if y < 100:
                    c.showPage()
                    y = height - 50
                    try:
                        c.setFont("SimHei", 12) if "SimHei" in pdfmetrics.getRegisteredFontNames() else c.setFont("Helvetica", 12)
                    except:
                        c.setFont("Helvetica", 12)
                
                c.drawString(100, y, f"{i}. {data.title}")
                y -= 20
                c.drawString(100, y, f"   来源：{'百度' if data.source == 'baidu' else '必应'}")
                y -= 20
                c.drawString(100, y, f"   日期：{data.crawled_at.strftime('%Y-%m-%d %H:%M')}")
                y -= 20
                c.drawString(100, y, f"   URL：{data.url[:100]}")
                y -= 20
                if data.content:
                    content_preview = data.content[:100] + "..." if len(data.content) > 100 else data.content
                    c.drawString(100, y, f"   内容摘要：{content_preview}")
                    y -= 20
                y -= 10
        
        c.save()
    
    return pdf_filename

@main_bp.route('/ai_analyze', methods=['POST'])
@login_required
def ai_analyze():
    selected_ids = request.form.getlist('selected_data')
    
    if not selected_ids:
        flash('请至少选择一条数据进行分析', 'danger')
        return redirect(url_for('main.data_warehouse'))
    
    try:
        # 获取选中的数据
        selected_data = CrawledData.query.filter(CrawledData.id.in_(selected_ids), CrawledData.saved_by == current_user.id).all()
        
        if not selected_data:
            flash('没有找到选中的数据', 'danger')
            return redirect(url_for('main.data_warehouse'))
        
        # 模拟AI分析功能
        # 这里可以替换为真实的AI模型调用
        ai_content = f"""
# AI数据分析报告

## 数据概览
- 分析数据数量：{len(selected_data)}条
- 数据来源分布：
  - 百度：{sum(1 for data in selected_data if data.source == 'baidu')}条
  - 必应：{sum(1 for data in selected_data if data.source == 'bing')}条

## 关键词分析
- 主要关键词：{selected_data[0].keyword}

## 内容摘要
{chr(10).join([f"- {data.title[:50]}..." for data in selected_data])}

## 分析结论
基于对{len(selected_data)}条相关数据的分析，我们可以得出以下结论：

1. 数据覆盖了与"{selected_data[0].keyword}"相关的多个方面，提供了较为全面的信息基础。

2. 通过对不同来源数据的交叉验证，可以发现信息的一致性和差异性，有助于更全面地理解研究主题。

3. 建议进一步深入分析核心内容，提取关键信息点，形成更有针对性的研究结论。
        """
        
        # 创建一个临时报告
        report = Report(
            title=f"AI分析报告 - {selected_data[0].keyword}",
            content=ai_content,
            created_by=current_user.id
        )
        
        # 添加选中的数据
        for data in selected_data:
            report.crawled_data.append(data)
        
        db.session.add(report)
        db.session.commit()
        
        # 自动生成PDF
        pdf_filename = generate_pdf(report)
        report.pdf_path = pdf_filename
        db.session.commit()
        
        flash('AI分析报告已生成', 'success')
        return redirect(url_for('main.report_detail', report_id=report.id))
        
    except Exception as e:
        db.session.rollback()
        flash(f'AI分析失败：{str(e)}', 'danger')
        return redirect(url_for('main.data_warehouse'))

@main_bp.route('/data_warehouse', methods=['GET', 'POST'])
@login_required
def data_warehouse():
    # 处理筛选和搜索
    filter_date = request.args.get('date', '')
    search_keyword = request.args.get('keyword', '')
    source_filter = request.args.get('source', '')
    
    # 构建查询
    query = CrawledData.query.filter_by(saved_by=current_user.id)
    
    # 按日期筛选
    if filter_date:
        try:
            filter_datetime = datetime.strptime(filter_date, '%Y-%m-%d')
            next_day = filter_datetime.replace(hour=23, minute=59, second=59)
            query = query.filter(CrawledData.crawled_at >= filter_datetime, CrawledData.crawled_at <= next_day)
        except ValueError:
            flash('无效的日期格式，请使用YYYY-MM-DD格式', 'danger')
    
    # 按关键词搜索
    if search_keyword:
        query = query.filter(CrawledData.title.like(f'%{search_keyword}%') | CrawledData.content.like(f'%{search_keyword}%'))
    
    # 按来源筛选
    if source_filter:
        query = query.filter(CrawledData.source == source_filter)
    
    # 按日期排序
    query = query.order_by(CrawledData.crawled_at.desc())
    
    # 分页
    page = request.args.get('page', 1, type=int)
    per_page = 10
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    data_list = pagination.items
    
    # 获取所有唯一日期用于筛选
    dates = db.session.query(db.func.date(CrawledData.crawled_at)).filter_by(saved_by=current_user.id).distinct().all()
    date_list = []
    for date in dates:
        if date[0]:
            if isinstance(date[0], str):
                # 如果已经是字符串格式，直接使用
                date_list.append(date[0])
            else:
                # 如果是日期对象，使用strftime格式化
                date_list.append(date[0].strftime('%Y-%m-%d'))
    
    # 确保所有数据项的crawled_at字段是日期对象
    for data in data_list:
        if hasattr(data, 'crawled_at') and data.crawled_at:
            # 这里不需要转换，因为数据库模型已经确保它是DateTime类型
            pass
    
    # 渲染模板并传递pagination变量
    return render_template('data_warehouse.html', 
                           pagination=pagination, 
                           data_list=data_list,
                           filter_date=filter_date, 
                           search_keyword=search_keyword, 
                           source_filter=source_filter, 
                           date_list=date_list)

@main_bp.route('/delete_data/<int:data_id>')
@login_required
def delete_data(data_id):
    data = CrawledData.query.get_or_404(data_id)
    if data.saved_by != current_user.id:
        flash('无权限删除该数据', 'danger')
        return redirect(url_for('main.data_warehouse'))
    
    try:
        db.session.delete(data)
        db.session.commit()
        flash('数据已成功删除', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除失败：{str(e)}', 'danger')
    
    return redirect(url_for('main.data_warehouse'))

@main_bp.route('/create_report', methods=['GET', 'POST'])
@login_required
def create_report():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        selected_data = request.form.getlist('selected_data')
        
        if not title:
            flash('报告标题不能为空', 'danger')
            return redirect(url_for('main.create_report'))
        
        try:
            # 创建报告
            report = Report(title=title, content=content, created_by=current_user.id)
            
            # 添加选中的数据
            if selected_data:
                for data_id in selected_data:
                    data = CrawledData.query.get(data_id)
                    if data:
                        report.crawled_data.append(data)
            
            # 保存到数据库
            db.session.add(report)
            db.session.commit()
            
            flash('报告已成功创建', 'success')
            return redirect(url_for('main.reports'))
        except Exception as e:
            db.session.rollback()
            flash(f'创建报告失败：{str(e)}', 'danger')
    
    # 获取用户所有爬取的数据
    crawled_data = CrawledData.query.filter_by(saved_by=current_user.id).order_by(CrawledData.crawled_at.desc()).all()
    
    return render_template('create_report.html', crawled_data=crawled_data)

@main_bp.route('/reports')
@login_required
def reports():
    # 获取用户的所有报告
    reports = Report.query.filter_by(created_by=current_user.id).order_by(Report.created_at.desc()).all()
    
    return render_template('reports.html', reports=reports)

@main_bp.route('/report/<int:report_id>')
@login_required
def report_detail(report_id):
    report = Report.query.get_or_404(report_id)
    if report.created_by != current_user.id:
        flash('无权限查看该报告', 'danger')
        return redirect(url_for('main.reports'))
    
    return render_template('report_detail.html', report=report)

@main_bp.route('/generate_pdf/<int:report_id>')
@login_required
def generate_pdf_route(report_id):
    report = Report.query.get_or_404(report_id)
    if report.created_by != current_user.id:
        flash('无权限生成该报告的PDF', 'danger')
        return redirect(url_for('main.reports'))
    
    try:
        # 生成PDF
        pdf_filename = generate_pdf(report)
        
        # 更新报告的PDF路径
        report.pdf_path = pdf_filename
        db.session.commit()
        
        flash('PDF报告已成功生成', 'success')
    except Exception as e:
        flash(f'生成PDF失败：{str(e)}', 'danger')
    
    return redirect(url_for('main.report_detail', report_id=report_id))

@main_bp.route('/download_pdf/<int:report_id>')
@login_required
def download_pdf(report_id):
    report = Report.query.get_or_404(report_id)
    if report.created_by != current_user.id:
        flash('无权限下载该PDF', 'danger')
        return redirect(url_for('main.reports'))
    
    if not report.pdf_path:
        flash('该报告尚未生成PDF', 'warning')
        return redirect(url_for('main.report_detail', report_id=report_id))
    
    # 获取当前应用实例
    from flask import current_app
    
    # 构建正确的PDF文件路径
    pdf_path = os.path.join(current_app.root_path, 'static', 'pdfs', report.pdf_path)
    if not os.path.exists(pdf_path):
        flash('PDF文件不存在', 'warning')
        return redirect(url_for('main.report_detail', report_id=report_id))
    
    # 使用send_from_directory发送文件
    return send_from_directory(os.path.join(current_app.root_path, 'static', 'pdfs'), report.pdf_path, as_attachment=True, download_name=f'{report.title}.pdf')

@main_bp.route('/delete_report/<int:report_id>')
@login_required
def delete_report(report_id):
    report = Report.query.get_or_404(report_id)
    if report.created_by != current_user.id:
        flash('无权限删除该报告', 'danger')
        return redirect(url_for('main.reports'))
    
    try:
        # 删除PDF文件
        if report.pdf_path:
            from flask import current_app
            pdf_path = os.path.join(current_app.root_path, 'static', 'pdfs', report.pdf_path)
            if os.path.exists(pdf_path):
                os.remove(pdf_path)
        
        # 删除报告
        db.session.delete(report)
        db.session.commit()
        
        flash('报告已成功删除', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除报告失败：{str(e)}', 'danger')
    
    return redirect(url_for('main.reports'))
