from app import db
from datetime import datetime
from flask_login import UserMixin

# 用户表
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # 关系
    crawled_data = db.relationship('CrawledData', backref='user', lazy=True)
    reports = db.relationship('Report', backref='user', lazy=True)

# 爬取数据表
class CrawledData(db.Model):
    __tablename__ = 'crawled_data'
    
    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(100), nullable=False)
    source = db.Column(db.String(20), nullable=False)  # baidu 或 bing
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text)
    url = db.Column(db.String(500), nullable=False)
    cover_url = db.Column(db.String(500))
    crawled_at = db.Column(db.DateTime, default=datetime.now)
    saved_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

# 报告模型（用于存储AI生成的报告）
class Report(db.Model):
    __tablename__ = 'reports'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    pdf_path = db.Column(db.String(500), nullable=True)  # 生成的PDF文件路径
    
    # 报告与爬取数据的多对多关系
    crawled_data = db.relationship('CrawledData', secondary='report_data', backref='reports')
    
    def __repr__(self):
        return f'<Report {self.title}>'

# 报告数据关联表
report_data = db.Table('report_data',
    db.Column('report_id', db.Integer, db.ForeignKey('reports.id'), primary_key=True),
    db.Column('crawled_data_id', db.Integer, db.ForeignKey('crawled_data.id'), primary_key=True)
)
