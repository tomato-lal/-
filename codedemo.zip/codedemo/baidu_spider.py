import requests
import re
import urllib.parse
import argparse
from bs4 import BeautifulSoup


def simple_text_extractor(html_content):
    """
    增强的HTML文本提取器，去除所有HTML标签、JavaScript、CSS和不必要的空白
    :param html_content: HTML内容
    :return: 提取的纯文本
    """
    # 1. 移除所有<script>标签及其内容
    text = re.sub(r'<script[^>]*>.*?</script>', '', html_content, flags=re.DOTALL)
    
    # 2. 移除所有<style>标签及其内容
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
    
    # 3. 移除所有<link>标签
    text = re.sub(r'<link[^>]*>', '', text)
    
    # 4. 移除所有<meta>标签
    text = re.sub(r'<meta[^>]*>', '', text)
    
    # 5. 移除所有<script>相关的代码
    text = re.sub(r'<script[^>]*>[\s\S]*?</script>', '', text)
    
    # 6. 移除所有HTML标签
    text = re.sub(r'<[^>]+>', '', text)
    
    # 7. 移除多余的空白字符
    text = re.sub(r'\s+', ' ', text)
    
    # 8. 移除首尾空白
    text = text.strip()
    
    return text


def baidu_spider(search_keyword, result_num=10):
    """
    百度搜索爬虫，使用BeautifulSoup解析数据，支持动态参数
    :param search_keyword: 搜索关键词
    :param result_num: 返回结果数量
    :return: 提取的结构化数据列表
    """
    # 对搜索关键词进行URL编码
    encoded_keyword = urllib.parse.quote(search_keyword)
    
    # 构建百度搜索URL
    url = f"https://www.baidu.com/s?wd={encoded_keyword}"
    
    # 设置请求头，模拟浏览器访问
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive"
    }
    
    try:
        # 发送HTTP请求
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()  # 检查请求是否成功
        
        # 设置正确的编码
        response.encoding = "utf-8"
        
        # 使用BeautifulSoup解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 提取搜索结果
        results = []
        
        # 查找所有搜索结果项
        # 百度搜索结果的HTML结构：通常使用id="1", id="2"这样的标识
        search_results = []
        
        # 方法1: 查找id以数字开头的div（这是百度搜索结果的主要标识方式）
        for i in range(1, result_num * 3 + 1):
            div = soup.find('div', id=str(i))
            if div:
                search_results.append(div)
        
        # 如果方法1没有找到结果，尝试其他方法
        if not search_results:
            # 方法2: 查找包含c-container类的div
            search_results = soup.find_all('div', class_='c-container', limit=result_num * 2)
        
        if not search_results:
            # 方法3: 查找包含result类的div
            search_results = soup.find_all('div', class_='result', limit=result_num * 2)
        
        # 解析每个搜索结果
        for item in search_results:
            if len(results) >= result_num:
                break
                
            result = {
                'title': '',
                'summary': '',
                'url': '',
                'cover_url': ''
            }
            
            # 提取标题和URL
            # 百度搜索结果的标题通常在h3标签内
            h3_tag = item.find('h3')
            if h3_tag:
                title_tag = h3_tag.find('a')
                if title_tag:
                    result['title'] = title_tag.get_text(strip=True)
                    result['url'] = title_tag.get('href', '')
            
            # 提取概要
            # 百度搜索结果的概要通常在class为'c-abstract'或'abstract'的div内
            summary_tag = item.find('div', class_='c-abstract')
            if not summary_tag:
                summary_tag = item.find('div', class_='abstract')
            if summary_tag:
                result['summary'] = summary_tag.get_text(strip=True)
            
            # 提取封面URL（如果有）
            img_tag = item.find('img')
            if img_tag:
                img_url = img_tag.get('src', '')
                # 排除base64编码的图片
                if img_url and not img_url.startswith('data:'):
                    # 如果是相对URL，转换为绝对URL
                    if img_url.startswith('/'):
                        img_url = f"https://www.baidu.com{img_url}"
                    result['cover_url'] = img_url
            
            # 只有当至少有标题和URL时才添加到结果列表
            if result['title'] and result['url']:
                results.append(result)
        
        return results
        
    except requests.RequestException as e:
        print(f"请求错误: {e}")
        return []
    except Exception as e:
        print(f"解析错误: {e}")
        return []


def bing_search_baidu(search_keyword, result_num=10):
    """
    使用必应搜索百度搜索结果的爬虫，使用BeautifulSoup解析数据
    :param search_keyword: 搜索关键词
    :param result_num: 返回结果数量
    :return: 提取的结构化数据列表
    """
    # 构建必应搜索URL，直接搜索关键词
    bing_url = f"https://cn.bing.com/search?q={urllib.parse.quote(search_keyword)}"
    
    # 设置请求头
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive"
    }
    
    try:
        # 发送HTTP请求
        response = requests.get(bing_url, headers=headers, timeout=10)
        response.raise_for_status()
        response.encoding = "utf-8"
        
        # 使用BeautifulSoup解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 提取搜索结果
        results = []
        
        # 查找所有搜索结果项
        # 必应搜索结果的HTML结构
        search_results = soup.find_all('li', class_='b_algo')
        
        # 解析每个搜索结果
        for item in search_results[:result_num]:
            result = {
                'title': '',
                'summary': '',
                'url': '',
                'cover_url': ''
            }
            
            # 提取标题和URL
            title_tag = item.find('h2').find('a') if item.find('h2') else None
            if title_tag:
                result['title'] = title_tag.get_text(strip=True)
                result['url'] = title_tag.get('href', '')
            
            # 提取概要
            summary_tag = item.find('p')
            if summary_tag:
                result['summary'] = summary_tag.get_text(strip=True)
            
            # 提取封面URL（如果有）
            cover_tag = item.find('img')
            if cover_tag:
                result['cover_url'] = cover_tag.get('src', '')
            
            # 只有当至少有标题和URL时才添加到结果列表
            if result['title'] and result['url']:
                results.append(result)
        
        return results
        
    except requests.RequestException as e:
        print(f"请求错误: {e}")
        return []
    except Exception as e:
        print(f"解析错误: {e}")
        return []


if __name__ == "__main__":
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='百度和必应搜索爬虫')
    parser.add_argument('-k', '--keyword', type=str, help='搜索关键词')
    parser.add_argument('-n', '--num', type=int, default=10, help='返回结果数量(仅百度直接搜索)')
    args = parser.parse_args()
    
    # 获取搜索关键词
    if args.keyword:
        # 如果通过命令行参数指定了关键词，显示确认信息
        search_keyword = args.keyword
        print(f"已使用命令行参数指定的搜索关键词: {search_keyword}")
        # 询问用户是否确认使用该关键词
        confirm = input("是否继续使用此关键词? (y/n): ")
        if confirm.lower() != 'y':
            # 用户不确认，重新输入
            while True:
                search_keyword = input("请输入新的搜索关键词: ").strip()
                if search_keyword:
                    break
                print("搜索关键词不能为空，请重新输入!")
    else:
        # 如果没有通过命令行参数指定关键词，获取用户输入并进行验证
        while True:
            search_keyword = input("请输入搜索关键词: ").strip()
            if search_keyword:
                break
            print("搜索关键词不能为空，请重新输入!")
    
    # 显示最终确定的搜索关键词
    print(f"\n开始搜索: {search_keyword}")
    
    # 更新baidu_spider函数中的结果数量限制
    result_num = args.num
    
    print("\n" + "=" * 60)
    print(f"搜索关键词: {search_keyword}")
    print(f"返回结果数量: {result_num}")
    print("=" * 60)
    
    # 1. 从百度搜索直接获取结果
    print("\n1. 从百度搜索直接获取的结果:")
    print("-" * 60)
    baidu_results = baidu_spider(search_keyword, result_num)
    if baidu_results:
        for i, result in enumerate(baidu_results, 1):
            print(f"\n结果 {i}:")
            print(f"标题: {result['title']}")
            print(f"概要: {result['summary']}")
            print(f"URL: {result['url']}")
            if result['cover_url']:
                print(f"封面URL: {result['cover_url']}")
            print("-" * 40)
    else:
        print("未找到相关结果")
    
    # 2. 从必应搜索百度链接获取结果
    print("\n\n2. 从必应搜索百度链接获取的结果:")
    print("-" * 60)
    bing_results = bing_search_baidu(search_keyword, result_num)
    if bing_results:
        for i, result in enumerate(bing_results, 1):
            print(f"\n结果 {i}:")
            print(f"标题: {result['title']}")
            print(f"概要: {result['summary']}")
            print(f"URL: {result['url']}")
            if result['cover_url']:
                print(f"封面URL: {result['cover_url']}")
            print("-" * 40)
    else:
        print("未找到相关结果")
    
    print("\n" + "=" * 60)
    print("爬取完成")
    print("=" * 60)
    print("\n使用示例:")
    print("  python baidu_spider.py --keyword '成都' --num 5")
    print("  python baidu_spider.py -k '北京' -n 10")
